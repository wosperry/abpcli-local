﻿namespace MyCompanyName.MyProjectName.Blazor.Server.Tiered.Pages;

public partial class Index
{

}
