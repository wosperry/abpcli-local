﻿using AutoMapper;

namespace MyCompanyName.MyProjectName.Web;

public class MyProjectNameWebAutoMapperProfile : Profile
{
    public MyProjectNameWebAutoMapperProfile()
    {
        //Define your AutoMapper configuration here for the Web project.
    }
}
