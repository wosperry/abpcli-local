﻿namespace MyCompanyName.MyProjectName.Blazor.Pages;

public partial class Index
{

}
