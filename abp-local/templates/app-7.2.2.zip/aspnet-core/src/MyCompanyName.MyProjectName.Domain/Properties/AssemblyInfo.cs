﻿using System.Runtime.CompilerServices;
[assembly:InternalsVisibleToAttribute("MyCompanyName.MyProjectName.Domain.Tests")]
[assembly:InternalsVisibleToAttribute("MyCompanyName.MyProjectName.TestBase")]
