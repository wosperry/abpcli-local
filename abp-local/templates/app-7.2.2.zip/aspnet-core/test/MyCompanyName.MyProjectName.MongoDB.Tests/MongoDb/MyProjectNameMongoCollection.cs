﻿using Xunit;

namespace MyCompanyName.MyProjectName.MongoDB;

[CollectionDefinition(MyProjectNameTestConsts.CollectionDefinitionName)]
public class MyProjectNameMongoCollection : MyProjectNameMongoDbCollectionFixtureBase
{

}
